let green = document.getElementById("green");
let black = document.getElementById("black");
let orange = document.getElementById("orange");

green.addEventListener("click",function(){
    document.body.style.background = "green"
})
black.addEventListener("click",function(){
    document.body.style.background = "black"
})
orange.addEventListener("click",function(){
    document.body.style.background = "orange"
})