let change = document.getElementById("change");
console.log(change)
let change2 =change.innerText.replaceAll("google" , "cybrom");
console.log(change2)
change.innerHTML= change2;

