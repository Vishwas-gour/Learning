let n1 = parseInt(prompt("Enter numb1"));
let n2 = parseInt(prompt("Enter numb1"));
let multi = n1*n2;
let div = n1/n2;
console.log(`multiplication of ${n1} & ${n2} = ${multi}`);
console.log(`division of ${n1} & ${n2} = ${div}`);
