function Home() {
    return (
      <>
      <section class="front">
            <section class="hero">
                <h2>Welcome to city Hospital</h2>
                <p>Your health is our priority. We provide top-notch medical services for you and your loved ones.</p>
                <button><a href="/3-Apppointment/appointment.html">Book an Appointment</a></button>
            </section>
        </section>
      </>
    )
  }
  export default Home;