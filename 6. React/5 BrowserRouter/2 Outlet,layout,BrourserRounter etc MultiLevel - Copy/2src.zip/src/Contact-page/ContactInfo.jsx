function ContactInfo() {
    return (
      <>
      Phone : 7727237349, 8038349238
      Gmail : khospital@gmail.com 
      </>
    )
  }
  export default ContactInfo;