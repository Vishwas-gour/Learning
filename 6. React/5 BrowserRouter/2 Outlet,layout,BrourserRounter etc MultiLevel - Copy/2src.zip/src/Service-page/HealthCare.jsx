function HealthCare() {
    return (
      <>
       <h3>Health Care page</h3>
  
      
      </>
    )
  }
  export default HealthCare;