function Oprations() {
    return (
        <>
            <h3>Oprations page</h3>
        </>
    )
}
export default Oprations;