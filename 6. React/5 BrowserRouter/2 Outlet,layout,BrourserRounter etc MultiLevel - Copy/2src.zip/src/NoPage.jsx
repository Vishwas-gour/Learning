function NoPage(){
return (
    <>
    <h1>No page Found</h1>
    </>
)
}
export default NoPage;