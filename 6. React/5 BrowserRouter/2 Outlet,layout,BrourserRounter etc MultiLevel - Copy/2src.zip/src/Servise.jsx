function Servise() {
    return (
      <>
       <h1>Servise page</h1>
      </>
    )
  }
  export default Servise;